package tnsif.kprit.demothread;

public class Demothread extends Thread {
public void run() {
		
		try {
			System.out.println("This thread is"+Thread.currentThread().getName()+"running");
		}
		catch(Exception e) {
			System.out.println("Exception caught");
		}
		
		
	}

}
